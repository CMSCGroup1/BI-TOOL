
public enum DisplayChoice {
	TABLE, COLUMN,GRAPH,STAT
}
